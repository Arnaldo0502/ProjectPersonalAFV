# Show-Desktop-Applet

Extension for Gnome Shell

A button that hide/show all the open windows on desktop

Install: [extensions.gnome.org](https://extensions.gnome.org/extension/4267/show-desktop-applet)

Forked from [amivaleo/Show-Desktop-Button](https://github.com/amivaleo/Show-Desktop-Button)
